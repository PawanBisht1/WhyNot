import SwiftUI

struct BounceButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.94 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct DateSelector: View {
    let dates: [AppDate]
    let selectedDate: AppDate
    let onSelect: (AppDate) -> Void
    @Namespace private var dateAnimation
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(dates) { appDate in
                    let isSelected = appDate.id == selectedDate.id
                    
                    VStack(spacing: 6) {
                        Text(appDate.dayString)
                            .font(.system(size: 11, weight: .bold))
                            .foregroundColor(isSelected ? .black : Theme.textMuted)
                        
                        Text(appDate.dateString)
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(isSelected ? .black : .white)
                    }
                    .frame(width: 65, height: 75)
                    .background(
                        ZStack {
                            if isSelected {
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color.white)
                                    .matchedGeometryEffect(id: "SelectedDate", in: dateAnimation)
                            }
                        }
                    )
                    .contentShape(Rectangle())
                    .onTapGesture {
                        withAnimation(.spring(response: 0.4, dampingFraction: 0.75)) { 
                            onSelect(appDate) 
                        }
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                RoundedRectangle(cornerRadius: 22)
                    .fill(Theme.cardBg)
                    .overlay(RoundedRectangle(cornerRadius: 22).stroke(Theme.border, lineWidth: 1))
            )
            .padding(.horizontal, 24)
        }
    }
}

struct CategoryCard: View {
    let category: TaskCategory
    let tasks: [TaskItem]
    let onAdd: () -> Void
    let onToggle: (TaskItem) -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top) {
                Image(systemName: category.iconName)
                    .font(.system(size: 18, weight: .regular))
                    .foregroundColor(Theme.accent)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(category.rawValue)
                        .font(.system(size: 16, weight: .bold))
                        .foregroundColor(.white)
                    
                    Text(category.subtitle)
                        .font(.system(size: 13, weight: .regular))
                        .foregroundColor(Theme.textMuted)
                }
                Spacer()
            }
            .padding(.horizontal, 18)
            .padding(.top, 18)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(tasks) { task in
                        TaskRow(task: task, onToggle: onToggle)
                    }
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            Rectangle()
                .fill(Theme.border)
                .frame(height: 1)
                .padding(.horizontal, 18)
            
            Button(action: onAdd) {
                HStack(spacing: 6) {
                    Image(systemName: "plus")
                        .font(.system(size: 12, weight: .black))
                    Text("Add")
                        .font(.system(size: 14, weight: .bold))
                }
                .foregroundColor(.black)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 14))
                .padding(.horizontal, 18)
                .padding(.bottom, 18)
                .padding(.top, 14) // add spacing above the button to pad from line
            }
            .buttonStyle(BounceButtonStyle())
        }
        .frame(height: 340) // Increased height to make the card bigger
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Theme.cardBg)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 24)
                .stroke(Theme.border, lineWidth: 1)
        )
    }
}

struct PrimaryActionButton: View {
    let title: String
    let icon: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .black))
                Text(title)
                    .font(.system(size: 18, weight: .bold))
            }
            .foregroundColor(.black)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 20)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 20))
        }
        .buttonStyle(BounceButtonStyle())
    }
}

struct TaskRow: View {
    @Bindable var task: TaskItem
    var onToggle: (TaskItem) -> Void
    
    var body: some View {
        Button(action: { onToggle(task) }) {
            HStack(alignment: .center, spacing: 12) {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(task.isCompleted ? Theme.accent : .gray)
                    .font(.system(size: 22)) 
                Text(task.title)
                    .font(.system(size: 18, weight: .semibold)) 
                    .foregroundColor(task.isCompleted ? Color.gray.opacity(0.8) : .white)
                    .strikethrough(task.isCompleted, color: Color.gray.opacity(0.8))
                    .multilineTextAlignment(.leading)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.vertical, 8) 
        }
        .buttonStyle(PlainButtonStyle())
        .animation(.easeInOut(duration: 0.2), value: task.isCompleted)
    }
}
