import SwiftUI
import SwiftData

struct ContentView: View {
    @State private var selectedTab = 0
    @Namespace private var tabAnimation
    @AppStorage("hasSeenOnboardingV2") private var hasSeenOnboarding: Bool = false
    @Environment(\.modelContext) private var modelContext
    
    var body: some View {
        Group {
            if !hasSeenOnboarding {
                OnboardingView(hasSeenOnboarding: $hasSeenOnboarding)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .onAppear {
                        // Clear old data on first run
                        do {
                            try modelContext.delete(model: TaskItem.self)
                            try modelContext.delete(model: DailyReflection.self)
                        } catch {
                            print("Failed to clear data")
                        }
                    }
            } else {
                mainAppView
            }
        }
        .animation(.spring(response: 0.5, dampingFraction: 0.8), value: hasSeenOnboarding)
        .preferredColorScheme(.dark)
    }
    
    private var mainAppView: some View {
        ZStack(alignment: .bottom) {
            Theme.bg.ignoresSafeArea()
            
            // Content
            ZStack {
                FocusView()
                    .opacity(selectedTab == 0 ? 1 : 0)
                    .allowsHitTesting(selectedTab == 0)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
                
                InsightsView()
                    .opacity(selectedTab == 1 ? 1 : 0)
                    .allowsHitTesting(selectedTab == 1)
                    .transition(.opacity.combined(with: .scale(scale: 0.98)))
            }
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: selectedTab)
            
            // Custom Floating Tab Bar mapped to new theme
            HStack(spacing: 8) {
                Button(action: { withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { selectedTab = 0 }}) {
                    VStack(spacing: 4) {
                        Image(systemName: "house.fill")
                            .font(.system(size: 20))
                        Text("Home")
                            .font(.system(size: 11, weight: .bold))
                    }
                    .foregroundColor(selectedTab == 0 ? Theme.accent : Theme.textMuted)
                    .frame(width: 70, height: 60)
                    .background(
                        ZStack {
                            if selectedTab == 0 {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color(red: 0.15, green: 0.18, blue: 0.25))
                                    .matchedGeometryEffect(id: "TabPill", in: tabAnimation)
                            }
                        }
                    )
                }
                .buttonStyle(BounceButtonStyle())
                
                Button(action: { withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) { selectedTab = 1 }}) {
                    VStack(spacing: 4) {
                        Image(systemName: "chart.bar.fill")
                            .font(.system(size: 20))
                        Text("Insights")
                            .font(.system(size: 11, weight: .bold))
                    }
                    .foregroundColor(selectedTab == 1 ? Theme.accent : Theme.textMuted)
                    .frame(width: 70, height: 60)
                    .background(
                        ZStack {
                            if selectedTab == 1 {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(Color(red: 0.15, green: 0.18, blue: 0.25))
                                    .matchedGeometryEffect(id: "TabPill", in: tabAnimation)
                            }
                        }
                    )
                }
                .buttonStyle(BounceButtonStyle())
            }
            .padding(.horizontal, 6)
            .padding(.vertical, 6)
            .background(
                RoundedRectangle(cornerRadius: 24)
                    .fill(Theme.cardBg)
                    .overlay(RoundedRectangle(cornerRadius: 24).stroke(Theme.border, lineWidth: 1))
            )
            .padding(.bottom, 24)
            
        }
        .ignoresSafeArea(.all, edges: .bottom)
    }
}
