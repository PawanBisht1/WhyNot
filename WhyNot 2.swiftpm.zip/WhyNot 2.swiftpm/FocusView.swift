import SwiftUI
import SwiftData

struct FocusView: View {
    @State private var dates = AppModel.generateDates()
    @State private var selectedDate: AppDate?
    @State private var showingReflectionSheet = false
    
    var body: some View {
        ZStack(alignment: .bottom) {
            Theme.bg.ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 28) {
                    Spacer().frame(height: 8) // Top padding
                                        
                    // Date Selector
                    if let selected = selectedDate {
                        DateSelector(dates: dates, selectedDate: selected) { newDate in
                            selectedDate = newDate
                        }
                        
                        // Dynamic Task Grid matching the precise selected date
                        TaskCategoryGrid(date: selected.date)
                            .id(selected.date)
                        // Action button natively flowing right below the cards - restricted to only today
                        if Calendar.current.isDateInToday(selected.date) {
                            PrimaryActionButton(title: "Today's Reflect", icon: "book.fill") {
                                showingReflectionSheet = true
                            }
                            .padding(.horizontal, 24)
                            .padding(.top, 12)
                        }
                    }
                    
                    Spacer().frame(height: 140) // Substantial space for custom bottom tab bar
                }
                .frame(maxWidth: .infinity)
            }
        }
        .onAppear {
            if selectedDate == nil, dates.count > 1 {
                selectedDate = dates[1] // Default to Today
            }
        }
        .sheet(isPresented: $showingReflectionSheet) {
            if let date = selectedDate?.date {
                ReflectionSheet(date: date)
            }
        }
    }
}

// Subview isolated so @Query works optimally based on `date` param
struct TaskCategoryGrid: View {
    let date: Date
    @Environment(\.modelContext) private var modelContext
    @Query private var allTasks: [TaskItem]
    
    @State private var showingAddTask = false
    @State private var taskTitle = ""
    @State private var categoryToAdd: TaskCategory?
    
    init(date: Date) {
        self.date = Calendar.current.startOfDay(for: date)
        let exactDate = self.date
        let nextDate = Calendar.current.date(byAdding: .day, value: 1, to: exactDate)!
        _allTasks = Query(filter: #Predicate<TaskItem> { item in
            item.date >= exactDate && item.date < nextDate
        }, sort: [SortDescriptor(\.creationDate)])
    }
    
    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                CategoryCard(category: .mattersMost, tasks: tasks(for: .mattersMost), onAdd: { showAdd(for: .mattersMost) }, onToggle: toggle)
                CategoryCard(category: .afterThat, tasks: tasks(for: .afterThat), onAdd: { showAdd(for: .afterThat) }, onToggle: toggle)
            }
            HStack(spacing: 16) {
                CategoryCard(category: .optional, tasks: tasks(for: .optional), onAdd: { showAdd(for: .optional) }, onToggle: toggle)
                CategoryCard(category: .dontDo, tasks: tasks(for: .dontDo), onAdd: { showAdd(for: .dontDo) }, onToggle: toggle)
            }
        }
        .padding(.horizontal, 24)
        // Basic Alert for quickly adding tasks natively
        .alert("Add Task", isPresented: $showingAddTask) {
            TextField("Task title", text: $taskTitle)
                .textInputAutocapitalization(.sentences)
            Button("Cancel", role: .cancel) { taskTitle = "" }
            Button("Add") {
                if let category = categoryToAdd, !taskTitle.isEmpty {
                    let newTask = TaskItem(title: taskTitle, category: category, date: date)
                    modelContext.insert(newTask)
                    taskTitle = ""
                }
            }
        } message: {
            Text("Add a task to \(categoryToAdd?.rawValue ?? "")")
        }
    }
    
    private func tasks(for category: TaskCategory) -> [TaskItem] {
        allTasks.filter { $0.category == category }
    }
    
    private func showAdd(for category: TaskCategory) {
        categoryToAdd = category
        showingAddTask = true
    }
    
    private func toggle(_ task: TaskItem) {
        task.isCompleted.toggle()
    }
}

struct ReflectionSheet: View {
    let date: Date
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Query private var reflections: [DailyReflection]
    @State private var reflectionText: String = ""
    
    init(date: Date) {
        self.date = Calendar.current.startOfDay(for: date)
        let exactDate = self.date
        let nextDate = Calendar.current.date(byAdding: .day, value: 1, to: exactDate)!
        _reflections = Query(filter: #Predicate<DailyReflection> { r in 
            r.date >= exactDate && r.date < nextDate
        })
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Theme.bg.ignoresSafeArea()
                
                VStack(alignment: .leading, spacing: 12) {
                    Text("Reflect on your day")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.white)
                        .padding(.horizontal)
                        .padding(.top, 24)
                    
                    Text("Did you focus on what Matters Most? What distracted you? Write a brief insight here.")
                        .font(.system(size: 14))
                        .foregroundColor(Theme.textMuted)
                        .padding(.horizontal)
                    
                    TextEditor(text: $reflectionText)
                        .scrollContentBackground(.hidden)
                        .padding(12)
                        .background(Theme.cardBg)
                        .cornerRadius(16)
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(Theme.border, lineWidth: 1))
                        .padding(.horizontal)
                        .foregroundColor(.white)
                    
                    Spacer()
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                        .foregroundColor(Theme.textMuted)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { save() }
                        .foregroundColor(.white)
                        .bold()
                }
            }
        }
        .onAppear {
            if let existing = reflections.first {
                reflectionText = existing.text
            }
        }
    }
    
    private func save() {
        if let existing = reflections.first {
            existing.text = reflectionText
        } else if !reflectionText.isEmpty {
            let newReflection = DailyReflection(text: reflectionText, date: date)
            modelContext.insert(newReflection)
        }
        dismiss()
    }
}
