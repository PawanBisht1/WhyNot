import Foundation
import SwiftData

struct WeeklyInsight {
    let title: String
    let description: String
    let iconName: String
    let colorHex: String
}

class InsightsEngine {
    static func generateWeeklyInsights(from reflections: [DailyReflection], tasks: [TaskItem]) -> [WeeklyInsight] {
        var insights: [WeeklyInsight] = []
        
        let now = Date()
        guard let sevenDaysAgo = Calendar.current.date(byAdding: .day, value: -7, to: now) else {
            return insights
        }
        
        // Filter to last 7 days
        let recentReflections = reflections.filter { $0.date >= sevenDaysAgo }
        let recentTasks = tasks.filter { $0.date >= sevenDaysAgo }
        
        if recentReflections.isEmpty && recentTasks.isEmpty {
            insights.append(WeeklyInsight(title: "Ready to Learn", description: "Your patterns and insights will appear here after your first few daily reflections or tasks.", iconName: "sparkles", colorHex: "F28C28"))
            return insights
        }
        
        // 1. Correlate with Tasks
        let priorityTasks = recentTasks.filter { $0.category == .mattersMost }
        let completedPriority = priorityTasks.filter { $0.isCompleted }
        
        let dontDoTasks = recentTasks.filter { $0.category == .dontDo }
        let avoidedDontDo = dontDoTasks.filter { !$0.isCompleted }
        
        if !priorityTasks.isEmpty {
            let completionRate = Double(completedPriority.count) / Double(priorityTasks.count)
            if completionRate <= 0.4 {
                insights.append(WeeklyInsight(title: "Scattered Attention", description: "You had some trouble finishing your main priorities this week. Try clearing your primary tasks earlier in the day.", iconName: "exclamationmark.arrow.triangle.2.circlepath", colorHex: "E05A47"))
            }
        }
        
        if dontDoTasks.count > 2 {
            let avoidanceRate = Double(avoidedDontDo.count) / Double(dontDoTasks.count)
            if avoidanceRate >= 0.7 {
                 insights.append(WeeklyInsight(title: "Strong Boundaries", description: "You successfully avoided most of your 'Don't Do' list. Setting these negative boundaries correlates with better focus.", iconName: "shield.fill", colorHex: "4CAF50"))
            } else {
                 insights.append(WeeklyInsight(title: "Leaky Boundaries", description: "You engaged with several items on your 'Don't Do' list. Awareness is the first step—try to identify your triggers.", iconName: "nosign", colorHex: "E05A47"))
            }
        }
        
        // 2. Analyze reflection sentiment/keywords using basic Foundation string matching
        if recentReflections.isEmpty {
            insights.append(WeeklyInsight(title: "Journal Empty", description: "Write daily reflections to get deeper insights.", iconName: "book", colorHex: "4A90E2"))
        } else {
            let combinedText = recentReflections.map { $0.text.lowercased() }.joined(separator: " ")
            
            let tiredKeywords = ["tired", "exhausted", "low energy", "burnout", "overwhelmed", "drained", "sick", "hard", "struggled"]
            let focusKeywords = ["focus", "productive", "crushed it", "flow", "good day", "energy", "great", "easy", "momentum", "clarity"]
            let distractionKeywords = ["distracted", "social media", "phone", "youtube", "scrolling", "interrupted"]
            
            let tiredCount = tiredKeywords.filter { combinedText.contains($0) }.count
            let focusCount = focusKeywords.filter { combinedText.contains($0) }.count
            let distCount = distractionKeywords.filter { combinedText.contains($0) }.count
            
            if tiredCount >= 2 {
                insights.append(WeeklyInsight(title: "Energy Check", description: "Words reflecting low energy or being overwhelmed appeared in your journal multiple times this week. Remember to prioritize rest.", iconName: "battery.25", colorHex: "E05A47"))
            }
            if focusCount >= 2 {
                insights.append(WeeklyInsight(title: "Zone of Focus", description: "You mentioned feeling focused and highly productive multiple times this week. Keep protecting that momentum!", iconName: "bolt.fill", colorHex: "F2C037"))
            }
            if distCount >= 2 {
                insights.append(WeeklyInsight(title: "Digital Distractions", description: "You noted digital distractions frequently. Consider setting hard timers for problem apps.", iconName: "iphone.slash", colorHex: "9E9E9E"))
            }
            
            if recentReflections.count >= 5 {
                insights.append(WeeklyInsight(title: "Consistent Tracking", description: "You logged reflections almost every day this week! This self-awareness is your strongest tool.", iconName: "flame.fill", colorHex: "FF5722"))
            }
        }
        
        // Default fallback if no immediate patterns trigger
        if insights.count == 0 {
            insights.append(WeeklyInsight(title: "Gathering Data", description: "Great job logging your days. Deeper patterns will emerge as you continue your journey.", iconName: "chart.xyaxis.line", colorHex: "4A90E2"))
        }
        
        return insights
    }
}
