import SwiftUI
import SwiftData

struct InsightsView: View {
    @Query private var reflections: [DailyReflection]
    @Query private var allTasks: [TaskItem]
    
    @State private var sortNewestFirst = true
    
    var sortedReflections: [DailyReflection] {
        reflections.sorted { sortNewestFirst ? $0.date > $1.date : $0.date < $1.date }
    }
    
    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 32) {
                    Spacer().frame(height: 24) // Top padding
                    
                    // Your Timeline Section
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            Image(systemName: "clock.arrow.circlepath")
                                .font(.system(size: 18, weight: .regular))
                                .foregroundColor(Theme.accent)
                            Text("Your Timeline")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(.white)
                            
                            Spacer()
                            
                            // Sorting Menu
                            Menu {
                                Button(action: { sortNewestFirst = true }) {
                                    HStack {
                                        Text("Newest First")
                                        if sortNewestFirst { Image(systemName: "checkmark") }
                                    }
                                }
                                Button(action: { sortNewestFirst = false }) {
                                    HStack {
                                        Text("Oldest First")
                                        if !sortNewestFirst { Image(systemName: "checkmark") }
                                    }
                                }
                            } label: {
                                Image(systemName: "arrow.up.arrow.down.circle.fill")
                                    .font(.system(size: 24))
                                    .foregroundColor(Theme.textMuted)
                            }
                        }
                        .padding(.horizontal, 24)
                        
                        if reflections.isEmpty {
                            VStack(spacing: 16) {
                                Image(systemName: "clock.arrow.circlepath")
                                    .font(.system(size: 40, weight: .regular))
                                    .foregroundColor(Theme.textMuted)
                                
                                Text("Your reflections will appear here.")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundColor(Theme.textMuted)
                                    .textCase(.uppercase)
                                    .kerning(1.0)
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 180)
                            .background(
                                RoundedRectangle(cornerRadius: 18)
                                    .fill(Theme.cardBg)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 18)
                                    .stroke(Theme.border, lineWidth: 1)
                            )
                            .padding(.horizontal, 24)
                        } else {
                            // Vertical Timeline list
                            VStack(spacing: 24) { // Increased spacing between cards
                                ForEach(sortedReflections) { reflection in
                                    VStack(alignment: .leading, spacing: 18) { 
                                        HStack(alignment: .top) {
                                            Text(dateString(from: reflection.date))
                                                .font(.system(size: 14, weight: .bold)) 
                                                .foregroundColor(Theme.textMuted)
                                                .textCase(.uppercase)
                                                .kerning(1.2) // Added letter spacing for premium feel
                                            Spacer()
                                            Image(systemName: "quote.opening")
                                                .font(.system(size: 28, weight: .black)) // Larger, bolder quote
                                                .foregroundColor(Theme.textMuted.opacity(0.15)) // Softer quote mark
                                        }
                                        
                                        Text(reflection.text)
                                            .font(.system(size: 19, weight: .regular)) // Slightly larger text
                                            .foregroundColor(Color.white.opacity(0.95)) // Softer white text
                                            .lineSpacing(6) // More breathable line spacing
                                            .lineLimit(nil) 
                                    }
                                    .padding(28) // Increased inner padding
                                    .frame(maxWidth: .infinity, alignment: .topLeading) 
                                    .background(
                                        RoundedRectangle(cornerRadius: 32) // Smoother corners 
                                            .fill(Theme.cardBg)
                                            .shadow(color: Color.black.opacity(0.2), radius: 10, x: 0, y: 5) // subtle shadow
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 32)
                                            .stroke(Theme.border.opacity(0.5), lineWidth: 1) // Softer border
                                    )
                                    .transition(.scale(scale: 0.95).combined(with: .opacity)) // Transition for sorting
                                }
                            }
                            .padding(.horizontal, 24)
                            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: sortNewestFirst) // Smooth sorting animation
                        }
                    }
                    
                    Spacer().frame(height: 140)
                }
                .frame(maxWidth: .infinity)
            }
        }
    }
    
    private func dateString(from date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
}
