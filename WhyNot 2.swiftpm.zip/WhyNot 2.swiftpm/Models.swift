import Foundation
import SwiftUI
import SwiftData

struct Theme {
    static let bg = Color(red: 0.05, green: 0.07, blue: 0.11)
    static let cardBg = Color(red: 0.10, green: 0.13, blue: 0.18)
    static let accent = Color(red: 0.95, green: 0.55, blue: 0.15)
    static let border = Color(red: 0.18, green: 0.21, blue: 0.26)
    static let textMuted = Color(red: 0.55, green: 0.60, blue: 0.65)
}

@Model
class TaskItem {
    var title: String
    var categoryRaw: String // Store raw value to ensure safety
    var isCompleted: Bool
    var date: Date
    var creationDate: Date
    
    init(title: String, category: TaskCategory, date: Date) {
        self.title = title
        self.categoryRaw = category.rawValue
        self.isCompleted = false
        self.date = Calendar.current.startOfDay(for: date)
        self.creationDate = Date()
    }
    
    @Transient
    var category: TaskCategory {
        get { TaskCategory(rawValue: categoryRaw) ?? .optional }
        set { categoryRaw = newValue.rawValue }
    }
}

@Model
class DailyReflection {
    var text: String
    var date: Date
    var creationDate: Date
    
    init(text: String, date: Date) {
        self.text = text
        self.date = Calendar.current.startOfDay(for: date)
        self.creationDate = Date()
    }
}

struct AppDate: Identifiable, Hashable {
    let id = UUID()
    let date: Date
    
    var dayString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE"
        return formatter.string(from: date).uppercased()
    }
    
    var dateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "d"
        return formatter.string(from: date)
    }
}

enum TaskCategory: String, CaseIterable, Codable {
    case mattersMost = "Matters Most"
    case afterThat = "After That"
    case optional = "Optional"
    case dontDo = "Don't Do"
    
    var subtitle: String {
        switch self {
        case .mattersMost: return "Define your day"
        case .afterThat: return "Once priorities are done"
        case .optional: return "Nice to do, no pressure"
        case .dontDo: return "Intentional boundaries"
        }
    }
    
    var iconName: String {
        switch self {
        case .mattersMost: return "star"
        case .afterThat: return "checkmark.circle"
        case .optional: return "heart"
        case .dontDo: return "nosign"
        }
    }
    
    var color: Color {
        return .white 
    }
}

struct AppModel {
    static func generateDates() -> [AppDate] {
        var dates: [AppDate] = []
        let today = Date()
        for i in -1...5 {
            if let date = Calendar.current.date(byAdding: .day, value: i, to: today) {
                dates.append(AppDate(date: date))
            }
        }
        return dates
    }
}

extension Date {
    var isToday: Bool {
        Calendar.current.isDateInToday(self)
    }
}

extension Color {
    init?(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        var rgb: UInt64 = 0

        guard Scanner(string: hexSanitized).scanHexInt64(&rgb) else { return nil }

        self.init(
            red: Double((rgb & 0xFF0000) >> 16) / 255.0,
            green: Double((rgb & 0x00FF00) >> 8) / 255.0,
            blue: Double(rgb & 0x0000FF) / 255.0
        )
    }
}
