import SwiftUI
import SwiftData

@main
struct WhyNotApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [TaskItem.self, DailyReflection.self])
    }
}
