import SwiftUI

struct OnboardingView: View {
    @Binding var hasSeenOnboarding: Bool
    @State private var currentStep = 0
    
    var body: some View {
        ZStack {
            Theme.bg.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                // Content Switcher
                TabView(selection: $currentStep) {
                    
                    // Welcome & Quote
                    VStack(spacing: 32) {
                        Image(systemName: "sparkles")
                            .font(.system(size: 60))
                            .foregroundColor(Theme.accent)
                        
                        Text("Welcome to WhyNot")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.white)
                        
                        VStack(spacing: 16) {
                            Text("\"At the centre of your being you have the answer; you know who you are and you know what you want.\"")
                                .font(.system(size: 20, weight: .medium))
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                                .italic()
                                .lineSpacing(6)
                            
                            Text("— Lao Tzu")
                                .font(.system(size: 16, weight: .regular))
                                .foregroundColor(Theme.textMuted)
                        }
                        .padding(32)
                        .background(
                            RoundedRectangle(cornerRadius: 24)
                                .fill(Theme.cardBg)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 24)
                                .stroke(Theme.border, lineWidth: 1)
                        )
                        .padding(.horizontal, 24)
                        
                    }
                    .tag(0)
                    
                    // Focus Explanation
                    VStack(spacing: 32) {
                        Image(systemName: "target")
                            .font(.system(size: 60))
                            .foregroundColor(Theme.accent)
                        
                        Text("Find Your Focus")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.white)
                        
                        VStack(alignment: .leading, spacing: 20) {
                            FeatureRow(icon: "star.fill", title: "Matters Most", description: "Identify the 1-3 tasks that will move the needle today.")
                            FeatureRow(icon: "list.bullet", title: "Secondary", description: "Other important things to get done, but only after your priorities.")
                            FeatureRow(icon: "nosign", title: "Don't Do", description: "Set boundaries. Actively declare what you will avoid doing today.")
                        }
                        .padding(32)
                        .frame(maxWidth: .infinity)
                        .background(
                            RoundedRectangle(cornerRadius: 24)
                                .fill(Theme.cardBg)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 24)
                                .stroke(Theme.border, lineWidth: 1)
                        )
                        .padding(.horizontal, 24)
                    }
                    .tag(1)
                    
                    // Timeline Explanation
                    VStack(spacing: 32) {
                        Image(systemName: "book.fill")
                            .font(.system(size: 60))
                            .foregroundColor(Theme.accent)
                        
                        Text("Reflect & Grow")
                            .font(.system(size: 32, weight: .bold))
                            .foregroundColor(.white)
                        
                        Text("At the end of each day, write a short reflection. Over time, your Timeline will become a beautiful journal of your thoughts, struggles, and momentum.")
                            .font(.system(size: 18))
                            .foregroundColor(Theme.textMuted)
                            .multilineTextAlignment(.center)
                            .lineSpacing(6)
                            .padding(.horizontal, 32)
                    }
                    .tag(2)
                    
                }
                .tabViewStyle(.page(indexDisplayMode: .always))
                .animation(.easeInOut, value: currentStep)
                
                Spacer()
                
                // Action Button
                PrimaryActionButton(
                    title: currentStep == 2 ? "Get Started" : "Next",
                    icon: currentStep == 2 ? "arrow.right" : "chevron.right"
                ) {
                    if currentStep < 2 {
                        withAnimation {
                            currentStep += 1
                        }
                    } else {
                        let impact = UIImpactFeedbackGenerator(style: .medium)
                        impact.impactOccurred()
                        withAnimation {
                            hasSeenOnboarding = true
                        }
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 48)
            }
        }
    }
}

struct FeatureRow: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(Theme.accent)
                .frame(width: 24)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundColor(.white)
                Text(description)
                    .font(.system(size: 15))
                    .foregroundColor(Theme.textMuted)
                    .lineSpacing(2)
            }
        }
    }
}
